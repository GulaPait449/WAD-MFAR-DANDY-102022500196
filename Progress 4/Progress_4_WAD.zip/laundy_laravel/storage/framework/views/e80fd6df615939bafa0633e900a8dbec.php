<?php $__env->startSection('content'); ?>
  <header class="hero">
    <h1>Daftar Layanan dan Tarif Laundry</h1>
    <p class="subtitle">Kelola paket cuci, harga, dan estimasi waktu</p>
  </header>

  <?php if(session('pesan')): ?>
    <div class="alert ok"><?php echo e(session('pesan')); ?></div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <div class="alert error">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  
  <?php if($edit ? auth()->user()->can('layanan.edit') : auth()->user()->can('layanan.tambah')): ?>
    <section class="Pesan">
      <h3><?php echo e($edit ? 'Ubah Layanan #' . $edit->id : 'Tambah Layanan'); ?></h3>

      <form method="POST" action="<?php echo e($edit ? route('layanan.update', $edit) : route('layanan.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($edit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

        <label for="jenis">Jenis (kode unik, mis. kiloan)</label>
        <input type="text" id="jenis" name="jenis" value="<?php echo e(old('jenis', $edit->jenis ?? '')); ?>" required>

        <label for="nama">Nama Layanan</label>
        <input type="text" id="nama" name="nama" value="<?php echo e(old('nama', $edit->nama ?? '')); ?>" required>

        <label for="harga">Harga (Rp)</label>
        <input type="number" id="harga" name="harga" min="0" value="<?php echo e(old('harga', $edit->harga ?? '')); ?>" required>

        <label for="satuan">Satuan (kg / pcs)</label>
        <input type="text" id="satuan" name="satuan" value="<?php echo e(old('satuan', $edit->satuan ?? '')); ?>" required>

        <label for="estimasi">Estimasi Waktu</label>
        <input type="text" id="estimasi" name="estimasi" value="<?php echo e(old('estimasi', $edit->estimasi ?? '')); ?>" required>

        <button type="submit" class="btn"><?php echo e($edit ? 'Simpan Perubahan' : 'Tambah Layanan'); ?></button>
        <?php if($edit): ?> <a class="link" href="<?php echo e(route('layanan.index')); ?>">Batal</a> <?php endif; ?>
      </form>
    </section>
  <?php endif; ?>

  <h2>Data Layanan</h2>
  <div class="table-wrap">
    <table>
      <tr>
        <th>No</th><th>Jenis</th><th>Nama</th><th>Harga</th><th>Estimasi</th>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['layanan.edit', 'layanan.hapus'])): ?> <th>Aksi</th> <?php endif; ?>
      </tr>

      <?php $__empty_1 = true; $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($l->id); ?></td>
          <td><?php echo e($l->jenis); ?></td>
          <td><?php echo e($l->nama); ?></td>
          <td>Rp<?php echo e(number_format($l->harga, 0, ',', '.')); ?> / <?php echo e($l->satuan); ?></td>
          <td><?php echo e($l->estimasi); ?></td>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['layanan.edit', 'layanan.hapus'])): ?>
            <td class="aksi">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('layanan.edit')): ?>
                <a class="btn btn-sm" href="<?php echo e(route('layanan.edit', $l)); ?>">Edit</a>
              <?php endif; ?>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('layanan.hapus')): ?>
                <form class="inline-form" method="POST" action="<?php echo e(route('layanan.destroy', $l)); ?>"
                      onsubmit="return confirm('Yakin hapus layanan ini?')">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                </form>
              <?php endif; ?>
            </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6">Belum ada layanan.</td></tr>
      <?php endif; ?>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Tugas\Praktikum WAD\Praktikum\Proggress 4\laundy_laravel\resources\views/layanan/index.blade.php ENDPATH**/ ?>