<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Layanan Laundry</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/laundry_laravel.css')); ?>">
</head>
<body>
  <?php if(auth()->guard()->check()): ?>
    <nav class="topbar">
      <div class="menu">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('layanan.lihat')): ?> <a href="<?php echo e(route('layanan.index')); ?>">Layanan &amp; Tarif</a> <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pesanan.lihat')): ?> <a href="<?php echo e(route('pesanan.index')); ?>">Pesanan</a> <?php endif; ?>
      </div>
      <div class="user">
        <span><?php echo e(auth()->user()->name); ?> <span class="badge badge-<?php echo e(auth()->user()->role); ?>"><?php echo e(auth()->user()->role); ?></span></span>
        <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline-form">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-sm">Keluar</button>
        </form>
      </div>
    </nav>
  <?php endif; ?>

  <main class="container wide">
    <?php echo $__env->yieldContent('content'); ?>
  </main>
</body>
</html>
<?php /**PATH C:\Tugas\Praktikum WAD\Praktikum\Proggress 4\laundy_laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>