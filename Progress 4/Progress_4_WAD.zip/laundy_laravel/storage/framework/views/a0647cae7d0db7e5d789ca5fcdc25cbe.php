<?php $__env->startSection('content'); ?>
  <header class="hero">
    <h1>Daftar Layanan dan Tarif Laundry</h1>
    <p class="subtitle">Pilih layanan yang paling sesuai dengan kebutuhan Anda</p>
  </header>

  <?php if(session('pesan')): ?>
    <div class="alert ok"><?php echo e(session('pesan')); ?></div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <div class="alert error">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  
  <section class="Card-grid">
    <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <article class="card <?php echo e($l->jenis == 'express' ? : ''); ?>">
        <h3><?php echo e($l->nama); ?></h3>
        <p class="price">Rp<?php echo e(number_format($l->harga, 0, ',', '.')); ?> <span>/ <?php echo e($l->satuan); ?></span></p>
        <p class="time">Estimasi waktu: <?php echo e($l->estimasi); ?></p>
      </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section>

  
  <?php if($edit ? auth()->user()->can('pesanan.edit') : auth()->user()->can('pesanan.tambah')): ?>
  <section class="Pesan">
    <h3><?php echo e($edit ? 'Ubah Pesanan #' . $edit->id : 'Pesan Layanan'); ?></h3>

    <form method="POST" action="<?php echo e($edit ? route('pesanan.update', $edit) : route('pesanan.store')); ?>">
      <?php echo csrf_field(); ?>
      <?php if($edit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

      <label for="nama">Nama</label>
      <input type="text" id="nama" name="nama" value="<?php echo e(old('nama', $edit->nama ?? '')); ?>" required>

      <label for="telepon">No. HP</label>
      <input type="tel" id="telepon" name="telepon" value="<?php echo e(old('telepon', $edit->telepon ?? '')); ?>" required>

      <label for="layanan_id">Jenis Layanan</label>
      <select id="layanan_id" name="layanan_id" required>
        <option value="">-- Pilih layanan --</option>
        <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($l->id); ?>" <?php if(old('layanan_id', $edit->layanan_id ?? '') == $l->id): echo 'selected'; endif; ?>>
            <?php echo e($l->nama); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      <label for="jumlah">Jumlah (kg / pcs)</label>
      <input type="number" id="jumlah" name="jumlah" min="0.5" step="0.5"
             value="<?php echo e(old('jumlah', $edit->jumlah ?? 1)); ?>" required>

      <?php if($edit): ?>
        <label for="status">Status</label>
        <select id="status" name="status">
          <?php $__currentLoopData = $daftar_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s); ?>" <?php if(old('status', $edit->status) == $s): echo 'selected'; endif; ?>><?php echo e($s); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      <?php endif; ?>

      <label for="alamat">Alamat</label>
      <textarea id="alamat" name="alamat" rows="3"><?php echo e(old('alamat', $edit->alamat ?? '')); ?></textarea>

      <button type="submit" class="btn"><?php echo e($edit ? 'Simpan Perubahan' : 'Kirim Pesanan'); ?></button>
    </form>
  </section>
  <?php endif; ?>

  
  <h2>Data Pesanan</h2>
  <div class="table-wrap">
    <table>
      <tr>
        <th>No</th><th>Nama</th><th>No. HP</th><th>Layanan</th>
        <th>Jumlah</th><th>Total</th><th>Status</th>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['pesanan.edit', 'pesanan.hapus'])): ?> <th>Aksi</th> <?php endif; ?>
      </tr>

      <?php $__empty_1 = true; $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($r->id); ?></td>
          <td><?php echo e($r->nama); ?></td>
          <td><?php echo e($r->telepon); ?></td>
          <td><?php echo e($r->layanan->nama); ?></td>
          <td><?php echo e($r->jumlah); ?> <?php echo e($r->layanan->satuan); ?></td>
          <td>Rp<?php echo e(number_format($r->total, 0, ',', '.')); ?></td>
          <td><?php echo e($r->status); ?></td>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['pesanan.edit', 'pesanan.hapus'])): ?>
          <td class="aksi">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pesanan.edit')): ?>
              <a class="btn btn-sm" href="<?php echo e(route('pesanan.edit', $r)); ?>">Edit</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pesanan.hapus')): ?>
              <form class="inline-form" method="POST" action="<?php echo e(route('pesanan.destroy', $r)); ?>"
                    onsubmit="return confirm('Yakin hapus pesanan ini?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
              </form>
            <?php endif; ?>
          </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="9">Belum ada pesanan.</td></tr>
      <?php endif; ?>
    </table>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Tugas\Praktikum WAD\Praktikum\Proggress 4\laundy_laravel\resources\views/pesanan/index.blade.php ENDPATH**/ ?>