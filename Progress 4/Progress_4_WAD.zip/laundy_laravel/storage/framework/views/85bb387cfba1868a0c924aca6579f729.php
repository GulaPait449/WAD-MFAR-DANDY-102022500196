<?php $__env->startSection('content'); ?>
  <div class="error-page">
    <h1>403</h1>
    <p>Anda tidak memiliki hak akses untuk halaman atau aksi ini.</p>
    <a class="link" href="<?php echo e(url('/')); ?>">Kembali ke beranda</a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Tugas\Praktikum WAD\Praktikum\Proggress 4\laundy_laravel\resources\views/errors/403.blade.php ENDPATH**/ ?>