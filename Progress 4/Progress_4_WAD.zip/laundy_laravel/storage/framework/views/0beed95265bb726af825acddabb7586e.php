<?php $__env->startSection('content'); ?>
  <div class="login-box">
    <h2>Masuk</h2>

    <?php if($errors->any()): ?>
      <div class="alert error"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login')); ?>">
      <?php echo csrf_field(); ?>
      <label for="email">Email</label>
      <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>

      <button type="submit" class="btn">Masuk</button>
    </form>

    <div class="akun-uji">
      Akun uji (password: <code>password</code>):<br>
      admin@laundry.test, petugas@laundry.test, pemilik@laundry.test
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Tugas\Praktikum WAD\Praktikum\Proggress 4\laundy_laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>